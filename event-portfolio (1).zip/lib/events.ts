export type EventProject = {
  slug: string
  title: string
  category: string
  location: string
  year: string
  guests: string
  blurb: string
  image: string
}

export const events: EventProject[] = [
  {
    slug: "amalfi-garden-wedding",
    title: "An Amalfi Garden Wedding",
    category: "Wedding",
    location: "Ravello, Italy",
    year: "2025",
    guests: "180 guests",
    blurb:
      "A weekend celebration set among lemon groves and sea cliffs, anchored by a hundred-foot dining table beneath a canopy of light.",
    image: "/events/garden-wedding.png",
  },
  {
    slug: "evening-for-the-arts",
    title: "An Evening for the Arts",
    category: "Gala",
    location: "The Wexler Ballroom, Chicago",
    year: "2025",
    guests: "420 guests",
    blurb:
      "A black-tie benefit raising two million dollars, choreographed around candlelight, a live orchestra, and a silent auction in the round.",
    image: "/events/charity-gala.png",
  },
  {
    slug: "halo-product-launch",
    title: "The Halo Launch",
    category: "Brand Launch",
    location: "Pier 70, San Francisco",
    year: "2024",
    guests: "650 guests",
    blurb:
      "A flagship product reveal pairing architectural staging with a single, decisive beam of light to introduce a new flagship device.",
    image: "/events/product-launch.png",
  },
  {
    slug: "rooftop-soiree",
    title: "Solstice Rooftop Soirée",
    category: "Private Party",
    location: "Tribeca, New York",
    year: "2024",
    guests: "120 guests",
    blurb:
      "A midsummer cocktail evening above the city, layered with hanging gardens, low lounge seating, and a slow build into the blue hour.",
    image: "/events/rooftop-soiree.png",
  },
  {
    slug: "coastal-arts-festival",
    title: "Coastline Arts Festival",
    category: "Festival",
    location: "Big Sur, California",
    year: "2024",
    guests: "2,400 guests",
    blurb:
      "A two-day open-air festival of music and craft, woven across the bluffs with flowing canopies and festoon-lit pathways.",
    image: "/events/coastal-festival.png",
  },
  {
    slug: "cellar-dinner-series",
    title: "The Cellar Dinner Series",
    category: "Private Dinner",
    location: "Sonoma, California",
    year: "2023",
    guests: "24 guests",
    blurb:
      "An intimate seasonal dinner in a candlelit stone cellar, designed as a single, unbroken table and a menu that unfolded over five hours.",
    image: "/events/intimate-dinner.png",
  },
]

export const testimonials = [
  {
    quote:
      "Maren turned a vague idea into the most beautiful night of our lives. Every detail felt inevitable, like it could not have been any other way.",
    name: "Eliza & Tomás Reyes",
    detail: "Amalfi Garden Wedding",
  },
  {
    quote:
      "Our gala raised more than ever before, and guests are still talking about the room. She designs feeling, not just décor.",
    name: "Priya Anand",
    detail: "Director, The Wexler Foundation",
  },
  {
    quote:
      "Flawless production under real pressure. Maren protected the vision while keeping a 650-person launch perfectly on schedule.",
    name: "Devon Clarke",
    detail: "VP Brand, Halo",
  },
]
