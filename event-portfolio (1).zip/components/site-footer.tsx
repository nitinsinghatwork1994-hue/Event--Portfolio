export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-secondary/40">
      <div className="mx-auto max-w-6xl px-6 py-12 lg:px-10">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="font-serif text-3xl font-medium tracking-tight text-foreground">
              Maren Vale
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              Event Design &amp; Production Studio
            </p>
          </div>
          <nav
            className="flex flex-wrap gap-x-8 gap-y-2 text-sm text-muted-foreground"
            aria-label="Footer"
          >
            <a href="#work" className="transition-colors hover:text-foreground">
              Work
            </a>
            <a href="#studio" className="transition-colors hover:text-foreground">
              Studio
            </a>
            <a href="#services" className="transition-colors hover:text-foreground">
              Services
            </a>
            <a href="#contact" className="transition-colors hover:text-foreground">
              Contact
            </a>
          </nav>
        </div>

        <div className="mt-10 flex flex-col gap-2 border-t border-border pt-6 text-xs uppercase tracking-[0.18em] text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <span>© {new Date().getFullYear()} Maren Vale Studio</span>
          <span>New York · Los Angeles · Worldwide</span>
        </div>
      </div>
    </footer>
  )
}
