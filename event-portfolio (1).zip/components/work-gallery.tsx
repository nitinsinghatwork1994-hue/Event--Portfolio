import Image from "next/image"
import { events } from "@/lib/events"

export function WorkGallery() {
  return (
    <section id="work" className="mx-auto max-w-6xl px-6 py-20 lg:px-10 lg:py-28">
      <div className="mb-12 flex flex-col gap-4 border-b border-border pb-8 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="mb-3 flex items-center gap-3 text-xs uppercase tracking-[0.3em] text-muted-foreground">
            <span className="h-px w-8 bg-accent" />
            Portfolio
          </p>
          <h2 className="font-serif text-4xl font-light tracking-tight text-foreground sm:text-5xl">
            A few evenings worth remembering
          </h2>
        </div>
        <p className="max-w-sm text-pretty text-sm leading-relaxed text-muted-foreground">
          Each project begins with a feeling and ends with a room that holds
          it. A selection from recent seasons across the studio.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-x-8 gap-y-16 md:grid-cols-2">
        {events.map((event, index) => (
          <article
            key={event.slug}
            className={`group flex flex-col ${
              index % 3 === 0 ? "md:col-span-2" : ""
            }`}
          >
            <div
              className={`relative w-full overflow-hidden rounded-sm bg-muted ${
                index % 3 === 0 ? "aspect-[16/9]" : "aspect-[4/5]"
              }`}
            >
              <Image
                src={event.image || "/placeholder.svg"}
                alt={`${event.title} — ${event.category} in ${event.location}`}
                fill
                sizes={
                  index % 3 === 0
                    ? "(max-width: 768px) 100vw, 1152px"
                    : "(max-width: 768px) 100vw, 560px"
                }
                className="object-cover transition-transform duration-700 ease-out group-hover:scale-[1.03]"
              />
              <span className="absolute left-4 top-4 rounded-full bg-background/85 px-3 py-1 text-[0.7rem] uppercase tracking-[0.18em] text-foreground backdrop-blur-sm">
                {event.category}
              </span>
            </div>

            <div className="mt-6 flex items-start justify-between gap-6">
              <div>
                <h3 className="font-serif text-2xl font-medium tracking-tight text-foreground">
                  {event.title}
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  {event.location}
                </p>
              </div>
              <div className="shrink-0 text-right text-xs uppercase tracking-[0.18em] text-muted-foreground">
                <p>{event.year}</p>
                <p className="mt-1">{event.guests}</p>
              </div>
            </div>

            <p className="mt-4 max-w-xl text-pretty leading-relaxed text-muted-foreground">
              {event.blurb}
            </p>
          </article>
        ))}
      </div>
    </section>
  )
}
