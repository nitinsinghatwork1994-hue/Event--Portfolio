export function Marquee() {
  const items = [
    "Weddings",
    "Galas & Benefits",
    "Brand Launches",
    "Private Dinners",
    "Festivals",
    "Corporate Offsites",
    "Milestone Celebrations",
  ]

  return (
    <section className="border-y border-border bg-secondary/40 py-5">
      <div className="flex items-center gap-10 overflow-hidden whitespace-nowrap">
        <div className="flex shrink-0 animate-[marquee_38s_linear_infinite] items-center gap-10">
          {[...items, ...items].map((item, i) => (
            <span
              key={i}
              className="flex items-center gap-10 font-serif text-xl italic text-foreground/70"
            >
              {item}
              <span aria-hidden="true" className="text-accent">
                ✦
              </span>
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}
