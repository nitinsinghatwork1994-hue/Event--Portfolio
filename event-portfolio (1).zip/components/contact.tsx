"use client"

import type React from "react"
import { useState } from "react"

export function Contact() {
  const [submitted, setSubmitted] = useState(false)

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <section id="contact" className="mx-auto max-w-6xl px-6 py-20 lg:px-10 lg:py-28">
      <div className="grid grid-cols-1 gap-14 lg:grid-cols-2">
        <div>
          <p className="mb-4 flex items-center gap-3 text-xs uppercase tracking-[0.3em] text-muted-foreground">
            <span className="h-px w-8 bg-accent" />
            Enquire
          </p>
          <h2 className="text-balance font-serif text-4xl font-light leading-tight tracking-tight text-foreground sm:text-5xl">
            Let&apos;s begin with a conversation.
          </h2>
          <p className="mt-6 max-w-md text-pretty leading-relaxed text-muted-foreground">
            We take on a limited number of events each season. Share a little
            about your celebration and we&apos;ll be in touch within two
            business days.
          </p>

          <div className="mt-10 space-y-4 border-t border-border pt-8 text-sm">
            <div className="flex items-center justify-between gap-4">
              <span className="uppercase tracking-[0.18em] text-muted-foreground">
                Email
              </span>
              <a
                href="mailto:hello@marenvale.studio"
                className="text-foreground transition-colors hover:text-accent"
              >
                hello@marenvale.studio
              </a>
            </div>
            <div className="flex items-center justify-between gap-4">
              <span className="uppercase tracking-[0.18em] text-muted-foreground">
                Studio
              </span>
              <span className="text-foreground">New York &amp; Los Angeles</span>
            </div>
            <div className="flex items-center justify-between gap-4">
              <span className="uppercase tracking-[0.18em] text-muted-foreground">
                Instagram
              </span>
              <a href="#" className="text-foreground transition-colors hover:text-accent">
                @marenvale.studio
              </a>
            </div>
          </div>
        </div>

        <div>
          {submitted ? (
            <div className="flex h-full min-h-64 flex-col items-start justify-center rounded-sm border border-border bg-secondary/40 p-10">
              <span className="font-serif text-3xl italic text-accent">
                Thank you.
              </span>
              <p className="mt-3 max-w-sm text-pretty leading-relaxed text-muted-foreground">
                Your note is on its way to the studio. We&apos;ll be in touch
                shortly to start dreaming together.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-6">
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                <Field label="Name" name="name" placeholder="Your full name" />
                <Field
                  label="Email"
                  name="email"
                  type="email"
                  placeholder="you@email.com"
                />
              </div>
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                <Field label="Event type" name="type" placeholder="Wedding, gala…" />
                <Field
                  label="Approx. date"
                  name="date"
                  placeholder="Month / Year"
                />
              </div>
              <div className="flex flex-col gap-2">
                <label
                  htmlFor="message"
                  className="text-xs uppercase tracking-[0.18em] text-muted-foreground"
                >
                  Tell us about it
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={4}
                  placeholder="A few words about your vision, guest count, and location…"
                  className="resize-none border-b border-border bg-transparent py-2 text-foreground placeholder:text-muted-foreground/60 focus:border-accent focus:outline-none"
                />
              </div>
              <button
                type="submit"
                className="mt-2 inline-flex w-fit items-center gap-2 rounded-full bg-foreground px-7 py-3 text-sm uppercase tracking-[0.2em] text-background transition-colors hover:bg-accent"
              >
                Send enquiry
                <span aria-hidden="true">→</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  )
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
}: {
  label: string
  name: string
  type?: string
  placeholder?: string
}) {
  return (
    <div className="flex flex-col gap-2">
      <label
        htmlFor={name}
        className="text-xs uppercase tracking-[0.18em] text-muted-foreground"
      >
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        placeholder={placeholder}
        className="border-b border-border bg-transparent py-2 text-foreground placeholder:text-muted-foreground/60 focus:border-accent focus:outline-none"
      />
    </div>
  )
}
