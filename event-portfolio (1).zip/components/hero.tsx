import Image from "next/image"

export function Hero() {
  return (
    <section id="top" className="relative">
      <div className="mx-auto max-w-6xl px-6 pt-16 lg:px-10 lg:pt-24">
        <p className="mb-8 flex items-center gap-3 text-xs uppercase tracking-[0.3em] text-muted-foreground">
          <span className="h-px w-8 bg-accent" />
          Selected work, 2018 — 2025
        </p>

        <h1 className="max-w-4xl text-balance font-serif text-5xl font-light leading-[1.05] tracking-tight text-foreground sm:text-6xl lg:text-7xl">
          Events composed with{" "}
          <span className="italic text-accent">quiet intention</span> and
          uncommon care.
        </h1>

        <div className="mt-10 flex flex-col gap-8 border-t border-border pt-8 md:flex-row md:items-end md:justify-between">
          <p className="max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            I&apos;m Maren — an event designer and producer crafting weddings,
            galas, launches, and gatherings that feel inevitable in their
            beauty and effortless in their making.
          </p>
          <a
            href="#work"
            className="inline-flex shrink-0 items-center gap-2 text-sm uppercase tracking-[0.2em] text-foreground transition-colors hover:text-accent"
          >
            View the portfolio
            <span aria-hidden="true">↓</span>
          </a>
        </div>
      </div>

      <div className="mx-auto mt-14 max-w-6xl px-6 lg:px-10">
        <div className="relative aspect-[16/10] w-full overflow-hidden rounded-sm sm:aspect-[16/8]">
          <Image
            src="/events/hero-tablescape.png"
            alt="An elegantly styled event tablescape with layered linens, candlelight, and a sculptural floral runner"
            fill
            priority
            sizes="(max-width: 1152px) 100vw, 1152px"
            className="object-cover"
          />
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-4 text-xs uppercase tracking-[0.2em] text-muted-foreground">
          <span>Tablescape study — The Cellar Dinner Series</span>
          <span>Sonoma, California</span>
        </div>
      </div>
    </section>
  )
}
