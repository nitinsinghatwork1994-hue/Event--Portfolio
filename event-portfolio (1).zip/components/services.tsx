export function Services() {
  const services = [
    {
      number: "01",
      title: "Design & Concept",
      description:
        "Mood, narrative, palette, and a complete visual language — translated into renderings and a tactile design book.",
    },
    {
      number: "02",
      title: "Full Production",
      description:
        "Vendor curation, budgets, logistics, and day-of management. We hold the timeline so you can hold the moment.",
    },
    {
      number: "03",
      title: "Floral & Tablescape",
      description:
        "Sculptural florals, custom linens, and bespoke place settings developed in-house for a singular, cohesive table.",
    },
    {
      number: "04",
      title: "Lighting & Atmosphere",
      description:
        "Considered lighting design, sound, and scenic builds that shape how a space feels as the evening unfolds.",
    },
  ]

  return (
    <section id="services" className="mx-auto max-w-6xl px-6 py-20 lg:px-10 lg:py-28">
      <div className="mb-14 max-w-2xl">
        <p className="mb-4 flex items-center gap-3 text-xs uppercase tracking-[0.3em] text-muted-foreground">
          <span className="h-px w-8 bg-accent" />
          What we do
        </p>
        <h2 className="text-balance font-serif text-4xl font-light tracking-tight text-foreground sm:text-5xl">
          A single studio, end to end
        </h2>
      </div>

      <div className="grid grid-cols-1 gap-px overflow-hidden rounded-sm border border-border bg-border sm:grid-cols-2">
        {services.map((service) => (
          <div
            key={service.number}
            className="group flex flex-col bg-background p-8 transition-colors hover:bg-secondary/50 lg:p-10"
          >
            <span className="font-serif text-2xl italic text-accent">
              {service.number}
            </span>
            <h3 className="mt-6 font-serif text-2xl font-medium tracking-tight text-foreground">
              {service.title}
            </h3>
            <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
              {service.description}
            </p>
          </div>
        ))}
      </div>
    </section>
  )
}
