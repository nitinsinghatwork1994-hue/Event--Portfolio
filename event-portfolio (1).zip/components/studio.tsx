import Image from "next/image"

export function Studio() {
  const stats = [
    { value: "120+", label: "Events produced" },
    { value: "9", label: "Years designing" },
    { value: "14", label: "Countries hosted" },
  ]

  return (
    <section
      id="studio"
      className="border-y border-border bg-secondary/40 py-20 lg:py-28"
    >
      <div className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-14 px-6 lg:grid-cols-2 lg:px-10">
        <div className="relative order-last aspect-[4/5] overflow-hidden rounded-sm lg:order-first">
          <Image
            src="/events/intimate-dinner.png"
            alt="An intimate candlelit dinner designed by the studio"
            fill
            sizes="(max-width: 1024px) 100vw, 560px"
            className="object-cover"
          />
        </div>

        <div>
          <p className="mb-4 flex items-center gap-3 text-xs uppercase tracking-[0.3em] text-muted-foreground">
            <span className="h-px w-8 bg-accent" />
            The Studio
          </p>
          <h2 className="text-balance font-serif text-4xl font-light leading-tight tracking-tight text-foreground sm:text-5xl">
            Design that disappears into the experience.
          </h2>
          <div className="mt-6 space-y-5 text-pretty leading-relaxed text-muted-foreground">
            <p>
              Maren Vale is a full-service event design and production studio.
              We work with a deliberately small number of clients each year so
              that every gathering receives our complete attention — from the
              first mood to the final candle.
            </p>
            <p>
              Our work spans the deeply personal and the highly produced, but
              the approach is constant: restraint, craft, and a quiet
              obsession with how a room makes people feel.
            </p>
          </div>

          <dl className="mt-10 grid grid-cols-3 gap-6 border-t border-border pt-8">
            {stats.map((stat) => (
              <div key={stat.label}>
                <dt className="font-serif text-3xl font-medium text-foreground">
                  {stat.value}
                </dt>
                <dd className="mt-1 text-xs uppercase tracking-[0.18em] text-muted-foreground">
                  {stat.label}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  )
}
