import { testimonials } from "@/lib/events"

export function Testimonials() {
  return (
    <section
      id="voices"
      className="border-y border-border bg-primary py-20 text-primary-foreground lg:py-28"
    >
      <div className="mx-auto max-w-6xl px-6 lg:px-10">
        <p className="mb-14 flex items-center gap-3 text-xs uppercase tracking-[0.3em] text-primary-foreground/60">
          <span className="h-px w-8 bg-accent" />
          In their words
        </p>

        <div className="grid grid-cols-1 gap-12 md:grid-cols-3">
          {testimonials.map((t) => (
            <figure key={t.name} className="flex flex-col">
              <span aria-hidden="true" className="font-serif text-5xl leading-none text-accent">
                &ldquo;
              </span>
              <blockquote className="mt-4 flex-1 text-pretty font-serif text-xl font-light italic leading-relaxed text-primary-foreground/90">
                {t.quote}
              </blockquote>
              <figcaption className="mt-6 border-t border-primary-foreground/15 pt-4">
                <p className="text-sm font-medium text-primary-foreground">
                  {t.name}
                </p>
                <p className="mt-1 text-xs uppercase tracking-[0.18em] text-primary-foreground/55">
                  {t.detail}
                </p>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}
