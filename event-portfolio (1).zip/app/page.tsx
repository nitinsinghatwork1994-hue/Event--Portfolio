import { SiteHeader } from "@/components/site-header"
import { Hero } from "@/components/hero"
import { Marquee } from "@/components/marquee"
import { WorkGallery } from "@/components/work-gallery"
import { Studio } from "@/components/studio"
import { Services } from "@/components/services"
import { Testimonials } from "@/components/testimonials"
import { Contact } from "@/components/contact"
import { SiteFooter } from "@/components/site-footer"

export default function Page() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <Hero />
        <Marquee />
        <WorkGallery />
        <Studio />
        <Services />
        <Testimonials />
        <Contact />
      </main>
      <SiteFooter />
    </div>
  )
}
